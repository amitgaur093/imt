<?php

class dbConnect {

    public static $dbh;

    public function __construct() {
        $hostname = 'localhost';
        $username = 'root';
        $password = '';

        try {
            if (!self::$dbh) {
                self::$dbh = new PDO("mysql:host=$hostname;dbname=imt", $username, $password);
                self::$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // <== add this line
            }
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function fetchAllData($sql) {
        $sth = self::$dbh->prepare($sql);
        $sth->execute();
        $result = $sth->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
    public function fetchData($sql) {
        $sth = self::$dbh->prepare($sql);
        $sth->execute();
        $result = $sth->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function manipulateData($sql) {
        $result = self::$dbh->exec($sql);
        return $result;
    }

}
