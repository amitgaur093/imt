<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require_once './dbConnect.php';
$dbconnect = new dbConnect();

class getturfdata {

    public function getTrufs() {
        global $dbconnect;
        $fetchingDate = $_GET['searchDate'];
        $sql = "SELECT turf_master.fieldname, turf_master.address, turf_slot.turf_solt_no, turf_slot.start_time, turf_slot.end_time, date '" . $fetchingDate . "' as bookdate FROM turf_master JOIN turf_slot ON turf_slot.turf_master_no = turf_master.srno WHERE turf_slot.turf_solt_no NOT IN (SELECT turf_slot_no FROM booked_slots WHERE booked_slots.booking_date = date '" . $fetchingDate . "')";
        $result = $dbconnect->fetchAllData($sql);
        $finalResult = array(
            'data' => $result,
            'status' => 'success');
        header('Content-type: application/json');
        echo json_encode($finalResult);
    }

    public function bookTurf() {
        global $dbconnect;
        $fetchingDate = $_GET['bookDate'];
        $slot = $_GET['slot'];
        $sql = "insert into booked_slots (turf_slot_no,booking_date) values (" . $slot . ",date '" . $fetchingDate . "')";
        $result = $dbconnect->manipulateData($sql);
        $finalResult = array(
            'data' => $result,
            'status' => 'success');
        header('Content-type: application/json');
        echo json_encode($finalResult);
    }

}

if (isset($_GET['getdata'])) {
    $getturfdata = new getturfdata;
    $getturfdata->getTrufs();
} elseif (isset($_GET['book'])) {
    $getturfdata = new getturfdata;
    $getturfdata->bookTurf();
}