<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once './dbConnect.php';
$dbconnect = new dbConnect();

class login {

    public function login_user() {
        global $dbconnect;
        $uname = $_POST['username'];
        $passwd = $_POST['passwd'];
        $sql = "SELECT * FROM user_master where login_name = '" . $uname . "' and passwd = '" . $passwd . "'";
        $result = $dbconnect->fetchData($sql);
        $finalResult = array(
            'data' => $result,
            'status' => 'success');
        header('Content-type: application/json');
        echo json_encode($finalResult);
    }

    public function register_user() {
        global $dbconnect;
        $uname = $_POST['uname'];
        $pnum = $_POST['phno'];
        $mailid = $_POST['email'];
        $username = $_POST['username'];
        $passwd = $_POST['passwd'];
        $sql = "insert into user_master (user_name,phno,email,login_name,passwd) values ('" . $uname . "'," . $pnum . ",'" . $mailid . "','" . $username . "','" . $passwd . "')";
        $result = $dbconnect->manipulateData($sql);
        $finalResult = array(
            'data' => $result,
            'status' => 'success');
        header('Content-type: application/json');
        echo json_encode($finalResult);
    }

}

if (isset($_POST['login'])) {
    $login = new login;
    $login->login_user();
} elseif (isset($_POST['register'])) {
    $login = new login;
    $login->register_user();
}
