var app = angular.module("myApp", ["ngRoute"]);
var $loggedin = 0;
app.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {
        $routeProvider
                .when("/", {
                    templateUrl: "templates/login.html",
                    controller: "loginCntrl"
                })
                .when("/home", {
                    templateUrl: "templates/main.html",
                    controller: "homeCntrl"
                })
                .when("/logout", {
                    templateUrl: "templates/login.html",
                    controller: "logoutCntrl"
                })
                .when("/register", {
                    templateUrl: "templates/register.html",
                    controller: "registerCntrl"
                })
                .otherwise({
                    redirectTo: 'templates/login.html'
                });
    }]);
app.controller("loginCntrl", function($scope, $location) {
    $scope.login = function() {

        var username = $scope.username;
        var password = $scope.password;
        $.post(
                "http://localhost:1234/apiservice/login.php",
                {username: username, passwd: password, login: true},
        function(data) {
            if (data['status'] == "success") {
                $loggedin = 1;
                console.log('In login function');
                $location.path("/home").replace();
            } else {
                alert("User Name or Password is incorrect");
                $location.path("/").replace();
            }
        }
        );
    };
});
app.controller("homeCntrl", function($scope, $rootScope, $location) {

    $scope.turfs = [
        {
            address: "Behind Seasons Hotel, Aundh",
            end_time: "09:00:00",
            fieldname: "Football",
            start_time: "08:00:00",
            turf_solt_no: "1"
        }
    ];
    console.log($loggedin);
    if ($loggedin == 0) {
        $location.path("/");
    } else {
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd;
        }
        if (mm < 10) {
            mm = '0' + mm;
        }
        var todayDate = yyyy + '-' + mm + '-' + dd;
        
        
        $("#searchDate").blur(function() {
            var searchDate = $("#searchDate").val();
            var result = searchDate.split("/");
            var sDate = result['2'] + "-" + result['1'] + "-" + result['0'];
            $.get(
                    "http://localhost:1234/apiservice/getturfdata.php?getdata=1&searchDate=" + sDate,
                    function(data) {
                        if (data['status'] == "success") {
                            $rootScope.$broadcast('records', data);
                        } else {
                            alert('Some problem while fetching. Please search after sometime');
                        }
                    }
            );
        });
        
        
        $scope.$on('records', listenrecords);
        function listenrecords(event, $data) {
            $scope.turfs = $data['data'];
            console.log($scope.turfs);
        }

        console.log(todayDate);
        $.get(
                "http://localhost:1234/apiservice/getturfdata.php?getdata=1&searchDate=" + todayDate,
                function(data) {

                    if (data['status'] == "success") {
                        $scope.turfs = data;
                        $rootScope.$broadcast('records', data);
//                        $location.path("/login");
                    } else {
                        alert('Some problem while fetching. Please search after sometime.');
                    }
                }
        );
    }

    $scope.bookSlot = function(i) {
        console.log(i);
        var slotNo = i.turf_solt_no;
        var bookDate = i.bookdate;

        $.get(
                "http://localhost:1234/apiservice/getturfdata.php?book=1&slot=" + slotNo + "&bookDate=" + bookDate,
                function(data) {
                    console.log(data);
                    if (data['status'] == "success") {
                        alert('Turf booked successfully.');
                    } else {
                        alert('Some problem while fetching. Please search after sometime.');
                    }
                }
        );
    };
});
app.controller("logoutCntrl", function($scope, $location) {

    if ($loggedin == 0) {
        $location.path("/").replace();
    } else {
        $loggedin = 0
        $location.path("/").replace();
    }
});
app.controller("registerCntrl", function($scope, $location) {
    $scope.register = function() {

        var uname = $scope.uname;
        var phno = $scope.pnum;
        var email = $scope.mailid;
        var username = $scope.username;
        var password = $scope.password;
        $.post(
                "http://localhost:1234/apiservice/login.php",
                {uname: uname, phno: phno, email: email, username: username, passwd: password, register: true},
        function(data) {
            if (data['status'] == "success") {
                console.log('Registered successfully');
                alert('Registered successfully');
                $location.path("/login").replace();
            } else {
                alert("Due to some problem could not register. Please try after sometime.");
                $location.path("/register").replace();
            }
        }
        );
    };
});